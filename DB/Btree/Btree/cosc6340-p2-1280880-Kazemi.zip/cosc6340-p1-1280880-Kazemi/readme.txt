
 Zeinab Kazemi 1280880
 Yaser Karbaschi 1357933
 Each of the students was responsible for different functions of the code. at the end we merged the codes into one project.
 The language used is:C++.
 in order to compile and run please do:
 g++ -o out main.cpp
 ./out <input.txt 